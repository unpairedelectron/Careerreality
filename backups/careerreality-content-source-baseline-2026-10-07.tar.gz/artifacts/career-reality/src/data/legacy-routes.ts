export type LegacyReplacement = {
  title: string;
  description: string;
  eyebrow: string;
  summary: string;
  destination: string;
  destinationLabel: string;
};

export const legacyCompanyReplacements: Record<string, LegacyReplacement> = {
  groww: {
    title: "Groww company coverage moved",
    description: "The Groww company signal is not in the current CareerReality dataset yet. Use the company desk for current coverage and request a focused read if you need one.",
    eyebrow: "Company read / moved",
    summary: "This indexed company page has been retained as a useful handoff instead of becoming a dead link. CareerReality currently publishes signals only when the evidence and freshness can be explained.",
    destination: "/companies",
    destinationLabel: "Open company intelligence",
  },
  postman: {
    title: "Postman company coverage moved",
    description: "The Postman company signal is not in the current CareerReality dataset yet. Use the company desk for current coverage and request a focused read if you need one.",
    eyebrow: "Company read / moved",
    summary: "This indexed company page has been retained as a useful handoff instead of becoming a dead link. CareerReality currently publishes signals only when the evidence and freshness can be explained.",
    destination: "/companies",
    destinationLabel: "Open company intelligence",
  },
};

export const legacyAiReplacements: Record<string, LegacyReplacement> = {
  "openai-o1-reasoning-shift": {
    title: "OpenAI reasoning coverage moved",
    description: "This older AI work-shift briefing has moved into CareerReality's broader AI career pulse, where changing tasks and practical verification questions stay together.",
    eyebrow: "AI desk / moved",
    summary: "The original briefing is no longer maintained as a standalone route. The AI desk now focuses on how changing task mixes affect career optionality, skills, and employer signals.",
    destination: "/ai",
    destinationLabel: "Open the AI career pulse",
  },
  "gpt-4-1-coding-reliability-shift": {
    title: "GPT-4.1 coding coverage moved",
    description: "This older AI work-shift briefing has moved into CareerReality's broader AI career pulse, where changing tasks and practical verification questions stay together.",
    eyebrow: "AI desk / moved",
    summary: "The original briefing is no longer maintained as a standalone route. The AI desk now focuses on how changing task mixes affect career optionality, skills, and employer signals.",
    destination: "/ai",
    destinationLabel: "Open the AI career pulse",
  },
  "google-gemini-enterprise-india-gcc-july-2026": {
    title: "Google Gemini enterprise coverage moved",
    description: "This AI and GCC briefing has moved into CareerReality's broader AI career pulse, where role impact and practical verification questions are kept together.",
    eyebrow: "AI desk / moved",
    summary: "The original briefing is no longer maintained as a standalone route. The AI desk now focuses on how changing task mixes affect career optionality, skills, and employer signals.",
    destination: "/ai",
    destinationLabel: "Open the AI career pulse",
  },
  "gcc-ai-hiring-bar-system-design-july-2026": {
    title: "GCC AI hiring coverage moved",
    description: "This GCC hiring briefing has moved into CareerReality's broader AI career pulse, with a focus on changing hiring signals and practical next steps.",
    eyebrow: "AI desk / moved",
    summary: "The original briefing is no longer maintained as a standalone route. The AI desk now focuses on how changing task mixes affect career optionality, skills, and employer signals.",
    destination: "/ai",
    destinationLabel: "Open the AI career pulse",
  },
};

export const legacyArticleReplacements: Record<string, LegacyReplacement> = {
  "the-7-year-career-plateau-nobody-warns-you-about": {
    title: "The seven-year career plateau moved",
    description: "This editorial page has moved into CareerReality's current engineering and career-strategy archive.",
    eyebrow: "Editorial / moved",
    summary: "The original standalone article is no longer in the active desk catalogue. The current archive keeps the same question alive through evidence-aware reads about career ceilings, seniority, and changing paths.",
    destination: "/article/engineering-career-ceiling-peak-at-35",
    destinationLabel: "Read the closest current feature",
  },
};

export function getLegacyCompanyReplacement(slug: string): LegacyReplacement | undefined {
  return legacyCompanyReplacements[slug];
}

export function getLegacyAiReplacement(slug: string): LegacyReplacement | undefined {
  return legacyAiReplacements[slug];
}

export function getLegacyArticleReplacement(slug: string): LegacyReplacement | undefined {
  return legacyArticleReplacements[slug];
}